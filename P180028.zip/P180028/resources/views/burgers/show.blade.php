@extends('layouts.layout')

@section('content')
<div class="wrapper burger-details">
    <h1>Order for {{ $burger->name }}</h1>
    <p class="type">Type - {{ $burger->type }}</p>
    <p class="type">Patty - {{ $burger->patty }}</p>
    <form action="/burgers/{{ $burger->id }}" method="POST">
        @csrf
        @method('DELETE')
        <button>Complete Order</button>
    </form>
</div>

<a href="/burgers" class="back">< - Back to all Burgers</a>
@endsection