@extends('layouts.layout')

@section('content')
<div class="wrapper create-burger">
    <h1>Create a New Burger</h1>
    <form action="/burgers" method="POST">
        @csrf
        <label for="name">Your Name</label>
        <input type="text" id="name" name="name">
        <label for="type">Choose Burger Type</label>
        <select name="type" id="type">
            <option value="Zinger">Zinger</option>
            <option value="Beef">Beef</option>
            <option value="Chicken">Chicken</option>
        </select>
        
        <label for="patty">Choose Patty Type</label>
        <select name="patty" id="patty">
            <option value="Single">Single</option>
            <option value="Double">Double</option>
            <option value="Triple">Triple</option>
        </select>
        <input type="submit" value="Order Burger">
    </form>

</div>
@endsection